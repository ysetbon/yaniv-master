# Training run 20261123-164659

| Setting | Value |
| --- | --- |
| Recipe | search |
| Net | a decider and 3 expert nets |
| Device | GPU NVIDIA GeForce RTX 5050 Laptop GPU (cuda) |
| Game processes | 11 |
| Effort | 0.7 |
| Started from | public/model/yaniv-net.json |
| Copied | – |
| Passes | 12 |
| Took | 50.0 min |
| Rounds searched a pass | 300 |
| Imagined deals a move | 48 |
| Confidence bar | 1.5 |
| Teacher | latest |
| Counter moves mixed in | 0.0 → 0.0 per searched move |
| Each pass tested on | 1000 rounds and 200 matches |

## Generations

Margin is the counter's points a round minus the net's: above 0, the net takes fewer points.

| Gen | Made by | Margin a round | Rounds won | Matches won | Teacher agreement | Decisions learned | Kept | Took |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | Started from yaniv-net.json | +1.18 | 52.6% | 134–66 (67.0%) | – | – | yes | 0.0 min |
| 1 | Search pass 1 | +1.52 | 54.1% | 131–69 (65.5%) | 92.2% | 4205 | yes | 3.7 min |
| 2 | Search pass 2 | +2.04 | 55.5% | 122–78 (61.0%) | 91.5% | 4152 | yes | 4.7 min |
| 3 | Search pass 3 | +1.14 | 54.0% | 126–74 (63.0%) | 93.8% | 4093 |  | 4.4 min |
| 4 | Search pass 4 | +1.28 | 53.1% | 129–71 (64.5%) | 92.4% | 4138 |  | 3.8 min |
| 5 | Search pass 5 | +2.01 | 56.4% | 123–77 (61.5%) | 91.7% | 4106 |  | 3.6 min |
| 6 | Search pass 6 | +2.06 | 56.2% | 118–82 (59.0%) | 93.0% | 4215 | yes | 4.5 min |
| 7 | Search pass 7 | +2.06 | 56.1% | 132–68 (66.0%) | 92.9% | 4109 |  | 4.6 min |
| 8 | Search pass 8 | +2.34 | 56.5% | 123–77 (61.5%) | 93.3% | 3960 | yes | 4.3 min |
| 9 | Search pass 9 | +1.54 | 53.7% | 121–79 (60.5%) | 92.1% | 4044 |  | 3.5 min |
| 10 | Search pass 10 | +2.25 | 56.2% | 133–67 (66.5%) | 93.3% | 4045 |  | 3.9 min |
| 11 | Search pass 11 | +1.65 | 54.2% | 131–69 (65.5%) | 92.4% | 4261 |  | 4.5 min |
| 12 | Search pass 12 | +1.63 | 55.4% | 126–74 (63.0%) | 93.1% | 4047 |  | 3.7 min |

## Gate replay

The top 4 generations by their own tests replayed the same 2000 rounds and 400 matches.

| Gen | Margin a round | Rounds won | Matches won | Its own test's margin |
| --- | --- | --- | --- | --- |
| 8 | +1.36 | 54.3% | 272–128 (68.0%) | +2.34 |
| 10 | +1.52 | 54.7% | 261–139 (65.2%) | +2.25 |
| 6 | +1.37 | 54.1% | 263–137 (65.8%) | +2.06 |
| 7 (pick) | +1.60 | 54.5% | 256–144 (64.0%) | +2.06 |

## Final check on new games

| Gen | Margin a round | Rounds won | Matches won |
| --- | --- | --- | --- |
| 7 | +1.75 | 55.7% | 256–144 (64.0%) |
| 0 | +1.71 | 55.2% | 251–149 (62.7%) |

**Gen 7 ships.** Against the greedy player it wins 65.4% of rounds, against random play 99.2%.
